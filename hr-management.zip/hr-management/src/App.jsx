import React from 'react'
import HRManagementTool from './HRManagementTool'

export default function App() {
  return <HRManagementTool />
}
